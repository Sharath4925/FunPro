<?php



$order_id = "ORD_".rand(0,99999);
$amt = 100;




?>
<h1 style="text-align:center;">Checkout Page</h1>
<form action="makeRequest.php" method="post">
<label>ORDER ID : </label>
<input type="text" name="orderid" value="<?php echo $order_id ?>" readonly><br/>
<label>AMOUNT : </label>
<input type="number" name="amount" value="<?php echo $amt ?>" readonly><br/>
<label>MOBILE : </label>
<input type="tel" name="mobile" required><br/>
<p style="font-size:12px;">(Your payGATE registered mobile number)</p>
<input type="submit" name="submit" value="Pay" >


</form>
