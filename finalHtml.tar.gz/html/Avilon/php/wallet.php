<?php
session_start();

$addr = $_SESSION['walletAddress'];



$JsonData =json_encode($post);
	$url = 'http://localhost:3001/wallet-info';
        
$ch = curl_init( $url );

$payload = json_encode( array( "address"=> $addr ) );
curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

$result = curl_exec($ch);
curl_close($ch);	

$dat = json.decode($result);
echo $dat->type;

/*
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://localhost:3001/transact");
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);   
$output = curl_exec($curl);
curl_close($curl);
*/



?>
