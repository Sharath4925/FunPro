<?php
session_start();
require('conn.php');


$email = $_POST['email'];
$password = md5($_POST['password']);

$userSql = "select user_id,address from users where email = '".$email."' and password = '".$password."'";

$userRes = mysqli_query($conn,$userSql);

$userNum = mysqli_num_rows($userRes);
$user_info = mysqli_fetch_assoc($userRes);

if($userNum == 0){

echo '<script>alert("You do not exist");window.open("../login.html","_self");</script>';

}else if($userNum == 1){
$profileSql = "select * from profiles where user_id = '".$user_info['user_id']."'";

$profileRes = mysqli_query($conn,$profileSql);

$user_profile = mysqli_fetch_assoc($profileRes);
$_SESSION['profile']=$user_profile;
$_SESSION['walletAddress']=$user_info['address'];
header('Location: ../light/dashboard.php');

}

?>
