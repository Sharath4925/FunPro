<?php

session_start();

require('conn.php');

$merchantWalletAddress = "0458f1b16647fddffa84f9a5fb0dd10b07da461ebaf220513124f0d873d57007bff02eb77164b1d698e35ac84da5a8ec5477d823dbcb9ace728c48f83ca98ad08b" ;
$callback_url="http://shizmodo.online/Avilon";
$amt = $_POST['amount'];
$order_id = $_POST['order_id'];
$mobile = $_POST['mobile'];


$payGateSql = "select walletAddress from profiles where mobile='".$mobile."'";

$payGateRes = mysqli_query($conn,$payGateSql);

if(payGateRes){
$payGateArray = mysqli_fetch_assoc($payGateRes);
$addr = $payGateArray['walletAddress'];




	$url = 'http://shizmodo.online:3005/transact';
        
$ch = curl_init( $url );

$payload = json_encode( array( "amount" => $amt , "recipient"=> $merchantWalletAddress , "wallet" => array("publicKey" => $addr) ) );

curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

$result = curl_exec($ch);
curl_close($ch);	

$dat = json_decode($result);
echo $dat->type;
if($dat->type == 'success'){
echo '<script>alert("Transaction successful!");window.open("'.$callback_url.'","_self");</script>';
}else{

echo '<script>alert("Transaction successful!");window.open("http"//shizmodo.online/Avilon/php/ACC.php","_self");</script>';

}


}
/*
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://localhost:3001/transact");
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);   
$output = curl_exec($curl);
curl_close($curl);
*/



?>
