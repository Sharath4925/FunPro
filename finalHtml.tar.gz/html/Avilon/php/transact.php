<?php
session_start();
require('conn.php');
$mobile = $_POST['mobile'];
$amt = $_POST['amount'];
$toSql = "select walletAddress from profiles where mobile = '".$mobile."'";

$toRes = mysqli_query($conn,$toSql);
$num = mysqli_num_rows($toRes);
if($num == 1){
$toAssoc = mysqli_fetch_assoc($toRes);
$to = $toAssoc['walletAddress'];

$JsonData =json_encode($post);
	$url = 'http://localhost:3001/transact';
        
$ch = curl_init( $url );
$wallet = array("publicKey"=>$_SESSION['walletAddress']);
$payload = json_encode( array( "recipient"=> $to , "amount"=> $amt,"wallet"=>$wallet ) );
curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

$result = curl_exec($ch);
curl_close($ch);
	
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://localhost:3001/mine-transaction");
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$output = curl_exec($curl);
curl_close($curl);

header('Location: ../light/dashboard.php');

}else{

echo '<script>alert("Recipient does not exist");window.open("../light/dashboard.php","_self");</script>';


}
/*
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://localhost:3001/transact");
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);   
$output = curl_exec($curl);
curl_close($curl);
*/



?>
