<?php

require('conn.php');

$fname = $_POST['FName'];
$lname = $_POST['LName'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
if(md5($_POST['pass']) == md5($_POST['cpass'])){
$pass = md5($_POST['pass']);
}

$user_id = "user_".rand(0,999999).$mobile."_".$email;


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://localhost:3001/createWallet");
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$output = curl_exec($curl);
curl_close($curl);

$jdata = json_decode($output,true);
$address = $jdata["wallet"];


$signupSql = "insert into users values('".$user_id."','".$email."','".$pass."','".$address['publicKey']."')";
$signupRes = mysqli_query($conn,$signupSql);
if($signupRes){

$signProfileSql = "insert into profiles values('".$user_id."','".$email."','".$address['publicKey']."','".$fname."','".$lname."','".$mobile."','','','','','','')";
$signProfileRes = mysqli_query($conn,$signProfileSql);


}else{

echo '<script>alert("Signup failed!");window.open("../signup.html","_self");</script>';


}
echo '<script>alert("Signup successful!");window.open("../login.html","_self");</script>';


?>

