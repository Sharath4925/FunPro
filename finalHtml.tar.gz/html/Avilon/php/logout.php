<?php
session_start();
$_SESSION['profile'] = "";
session_unset();



header('Location: ../index.php');
?>
