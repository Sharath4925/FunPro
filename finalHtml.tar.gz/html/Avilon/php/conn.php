<?php
define("DBUSER","root");
define("DBHOST","localhost");
define("DBPASS","12345");
define("DB","cryptoDB");
/*
$username = "root";
$password = "12345";
$servername = "localhost";
$db="shio";
*/

$conn = mysqli_connect(DBHOST, DBUSER, DBPASS,DB);


if(!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


?>
