<?php
session_start();
require('conn.php');

echo '<script>alert("HHHH");</script>';

//$logAddrSql = "update users set address = '".$addr."' where user_id = '".$user_id."'";
//$res = mysqli_query($conn,$logAddrSql);



?>
